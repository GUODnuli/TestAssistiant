from httprunner import __version__


def get_httprunner_version():
    return __version__


def sum_two(m, n):
    return m + n


def get_variables():
    return {"foo1": "session_bar1"}
