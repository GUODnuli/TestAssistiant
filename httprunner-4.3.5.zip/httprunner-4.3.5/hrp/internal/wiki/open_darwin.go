package wiki

const openCmd = "open"
