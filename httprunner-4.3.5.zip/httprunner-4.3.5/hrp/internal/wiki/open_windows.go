package wiki

const openCmd = "explorer"
