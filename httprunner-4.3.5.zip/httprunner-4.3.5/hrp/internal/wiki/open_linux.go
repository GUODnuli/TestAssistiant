package wiki

const openCmd = "xdg-open"
