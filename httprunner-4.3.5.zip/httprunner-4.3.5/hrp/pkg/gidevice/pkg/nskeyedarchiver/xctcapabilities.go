package nskeyedarchiver

type XCTCapabilities struct {
	internal map[string]interface{}
}

func (caps *XCTCapabilities) archive(objects []interface{}) []interface{} {
	// TODO caps
	return nil
}
