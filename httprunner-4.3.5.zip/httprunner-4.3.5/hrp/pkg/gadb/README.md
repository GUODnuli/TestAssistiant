# gadb

This module is initially forked from [electricbubble/gadb@v0.0.7] and optimized by [@appl3s].

- feat: add reverse forward command
- feat: add `RunShellCommandV2` which supports running nohup
- feat: add `InstallAPK` with feature judgment
- feat: add `Uninstall` for specified package name

[electricbubble/gadb@v0.0.7]: https://github.com/electricbubble/gadb/tree/v0.0.7
[@appl3s]: https://github.com/appl3s
