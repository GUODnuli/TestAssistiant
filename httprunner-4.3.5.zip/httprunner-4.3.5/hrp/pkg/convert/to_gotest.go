package convert

// TODO: convert TCase to gotest case
func (c *TCaseConverter) toGoTest() (string, error) {
	return "", nil
}
