# boomer

This module is initially forked from [myzhan/boomer@v1.6.0] and made a lot of changes.

[myzhan/boomer@v1.6.0]: https://github.com/myzhan/boomer/tree/v1.6.0
