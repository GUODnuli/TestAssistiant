This directory contains x509 certificates and associated private keys used in
examples.

How were these test certs/keys generated ?
------------------------------------------
Run `./create.sh`
