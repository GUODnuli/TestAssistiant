---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: pending
---

## Background

> Focus on describing the problems encountered: In what scenarios, the current features of HttpRunner cannot achieve the requirements.

## Desired features

> What functional features are expected from HttpRunner.

## Example description (optional)

> Describing with examples helps developers to more accurately understand your needs.